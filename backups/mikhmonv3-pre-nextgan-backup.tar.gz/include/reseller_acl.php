<?php
/*
 *  Copyright (C) 2018 Laksamadi Guko.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

if (substr($_SERVER["REQUEST_URI"], -16) == "reseller_acl.php") {
    header("Location:./");
    exit;
}

/**
 * Complete catalog of granular permissions across all original Mikhmon v3 modules and actions.
 */
function getAllMikhmonPermissionDefinitions() {
    return array(
        'Hotspot Users & Vouchers' => array(
            'view_dashboard'      => 'View Dashboard & System Resource',
            'view_users'          => 'View Hotspot Users & Voucher Lists',
            'add_user'            => 'Add Single Hotspot User',
            'generate_voucher'    => 'Generate Batch Vouchers',
            'edit_user'           => 'View & Edit Hotspot User Details',
            'delete_user'         => 'Delete Hotspot Users (Single / Comment / Expired)',
            'enable_disable_user' => 'Enable, Disable & Reset Hotspot Users',
            'print_voucher'       => 'Print Vouchers (Default / QR / Small / BT / Quick Print)',
            'manage_quickprint'   => 'Manage Quick Print Packages',
            'export_users'        => 'Export Hotspot Users (Script / CSV)',
        ),
        'Hotspot Profiles & Active Sessions' => array(
            'view_profiles'       => 'View Hotspot User Profiles',
            'add_profile'         => 'Add Hotspot User Profile',
            'edit_profile'        => 'Edit Hotspot User Profile & Sync ROS6/ROS7 Scripts',
            'delete_profile'      => 'Delete Hotspot User Profile',
            'view_active'         => 'View Hotspot Active Sessions',
            'disconnect_active'   => 'Disconnect Active Hotspot User',
        ),
        'Network (Hosts, IP Bindings, Cookies, DHCP, Traffic)' => array(
            'view_hosts'          => 'View Hotspot Hosts',
            'manage_hosts'        => 'Remove Hosts & Make IP Bindings',
            'view_ipbinding'      => 'View Hotspot IP Bindings',
            'manage_ipbinding'    => 'Add, Enable, Disable & Remove IP Bindings',
            'view_cookies'        => 'View Hotspot Cookies',
            'delete_cookies'      => 'Delete Hotspot Cookies',
            'view_dhcp'           => 'View DHCP Leases',
            'view_traffic'        => 'View Interface Traffic Monitor',
        ),
        'Logs, Reports, System & PPP' => array(
            'view_logs'           => 'View Hotspot Log & User Log',
            'view_report'         => 'View & Print Selling Reports & Live Report',
            'export_report'       => 'Export Selling Report (CSV)',
            'delete_report'       => 'Delete Selling Report Records',
            'view_scheduler'      => 'View System Scheduler',
            'manage_scheduler'    => 'Enable, Disable & Remove System Schedulers',
            'reboot_shutdown'     => 'Reboot & Shutdown Router',
            'view_ppp'            => 'View PPP Secrets, Profiles & Active',
            'manage_ppp'          => 'Add, Edit, Enable, Disable & Remove PPP Items',
            'manage_router_settings' => 'Modify Router Session Settings, Logo & Voucher Template',
        ),
    );
}

/**
 * Return flat map of all permission keys => default boolean value
 */
function getDefaultPermissionMap($defaultVal = false) {
    $map = array();
    foreach (getAllMikhmonPermissionDefinitions() as $group => $items) {
        foreach ($items as $key => $label) {
            $map[$key] = (bool)$defaultVal;
        }
    }
    return $map;
}

/**
 * Standard Reseller permission preset
 */
function getStandardSellerPermissions() {
    $map = getDefaultPermissionMap(false);
    $enabled = array(
        'view_dashboard',
        'view_users',
        'add_user',
        'generate_voucher',
        'edit_user',
        'print_voucher',
        'view_profiles',
        'view_active',
        'view_logs',
        'view_report',
    );
    foreach ($enabled as $k) {
        $map[$k] = true;
    }
    return $map;
}

/**
 * Parse all configured router session names from include/config.php
 */
function getConfiguredRouterSessions($configFilePath = null) {
    if ($configFilePath === null) {
        $configFilePath = __DIR__ . '/config.php';
    }
    if (!file_exists($configFilePath)) {
        return array();
    }
    $routers = array();
    foreach (file($configFilePath) as $line) {
        $parts = explode("'", $line);
        if (isset($parts[1])) {
            $sesname = trim($parts[1]);
            if ($sesname !== '' && $sesname !== 'mikhmon' && strpos($line, '$data[') !== false) {
                $routers[$sesname] = $sesname;
            }
        }
    }
    return array_values($routers);
}

/**
 * Path to resellers storage file
 */
function getResellersStoragePath() {
    return __DIR__ . '/resellers.json';
}

/**
 * Load all configured resellers from include/resellers.json
 */
function loadResellers() {
    $path = getResellersStoragePath();
    if (!file_exists($path)) {
        $defaultRouters = getConfiguredRouterSessions();
        $r1 = isset($defaultRouters[0]) ? array($defaultRouters[0]) : array('MikroTik-ROS7');
        $r2 = isset($defaultRouters[1]) ? array($defaultRouters[1]) : array('MikroTik-ROS6');
        $seed = array(
            array(
                'id' => 'res_kiosk_utara',
                'username' => 'kiosk_utara',
                'name' => 'Kiosk Utara Cellular',
                'password_hash' => password_hash('kiosk123', PASSWORD_DEFAULT),
                'password_enc' => function_exists('encrypt') ? encrypt('kiosk123') : base64_encode('kiosk123'),
                'status' => 'active',
                'allowed_routers' => $r1,
                'permissions' => getStandardSellerPermissions(),
                'created_at' => '2026-10-20 09:00:00',
            ),
            array(
                'id' => 'res_mitra_selatan',
                'username' => 'mitra_selatan',
                'name' => 'Mitra Selatan Net',
                'password_hash' => password_hash('mitra123', PASSWORD_DEFAULT),
                'password_enc' => function_exists('encrypt') ? encrypt('mitra123') : base64_encode('mitra123'),
                'status' => 'active',
                'allowed_routers' => $r2,
                'permissions' => array_merge(getStandardSellerPermissions(), array(
                    'disconnect_active' => true,
                    'delete_user' => true,
                    'enable_disable_user' => true,
                )),
                'created_at' => '2026-10-21 11:30:00',
            ),
        );
        @file_put_contents($path, json_encode($seed, JSON_PRETTY_PRINT));
        return $seed;
    }
    $raw = @file_get_contents($path);
    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        return array();
    }
    // Ensure all permission keys exist on loaded records
    $defaults = getDefaultPermissionMap(false);
    foreach ($decoded as $idx => $res) {
        $perms = isset($res['permissions']) && is_array($res['permissions']) ? $res['permissions'] : array();
        // Map legacy keys if present
        if (!empty($perms['add_single_user'])) {
            $perms['add_user'] = true;
        }
        if (!empty($perms['view_reports'])) {
            $perms['view_report'] = true;
        }
        if (!empty($perms['delete_reports'])) {
            $perms['delete_report'] = true;
        }
        if (!empty($perms['manage_profiles'])) {
            $perms['view_profiles'] = true;
            $perms['add_profile'] = true;
            $perms['edit_profile'] = true;
            $perms['delete_profile'] = true;
        }
        $decoded[$idx]['permissions'] = array_merge($defaults, $perms);
    }
    return $decoded;
}

/**
 * Save resellers array to include/resellers.json
 */
function saveResellers($resellers) {
    $path = getResellersStoragePath();
    return @file_put_contents($path, json_encode(array_values($resellers), JSON_PRETTY_PRINT)) !== false;
}

/**
 * Verify password against a reseller record
 */
function verifyResellerPassword($reseller, $plainPassword) {
    if (!empty($reseller['password_hash']) && password_verify($plainPassword, $reseller['password_hash'])) {
        return true;
    }
    if (!empty($reseller['password_enc']) && function_exists('decrypt')) {
        if (decrypt($reseller['password_enc']) === $plainPassword) {
            return true;
        }
    }
    return false;
}

/**
 * Authenticate user as Admin or Reseller
 */
function authenticateMikhmonUser($username, $password, $useradm, $passadm_decrypted) {
    $username = trim((string)$username);
    $password = (string)$password;

    if ($username === $useradm && $password === $passadm_decrypted) {
        return array(
            'authenticated' => true,
            'role' => 'admin',
            'username' => $username,
            'name' => 'Administrator',
            'allowed_routers' => array('*'),
            'permissions' => getDefaultPermissionMap(true),
        );
    }

    $resellers = loadResellers();
    foreach ($resellers as $reseller) {
        if (isset($reseller['username']) && $reseller['username'] === $username) {
            if (!isset($reseller['status']) || $reseller['status'] !== 'active') {
                return array(
                    'authenticated' => false,
                    'error' => 'Reseller account is deactivated.',
                );
            }
            if (verifyResellerPassword($reseller, $password)) {
                return array(
                    'authenticated' => true,
                    'role' => 'reseller',
                    'id' => $reseller['id'],
                    'username' => $reseller['username'],
                    'name' => isset($reseller['name']) ? $reseller['name'] : $reseller['username'],
                    'allowed_routers' => isset($reseller['allowed_routers']) && is_array($reseller['allowed_routers']) ? $reseller['allowed_routers'] : array(),
                    'permissions' => isset($reseller['permissions']) && is_array($reseller['permissions']) ? $reseller['permissions'] : getDefaultPermissionMap(false),
                );
            }
        }
    }

    return array('authenticated' => false);
}

/**
 * Refresh active reseller session permissions and router assignments from disk on every request
 * so admin changes take effect immediately without requiring reseller re-login.
 */
function syncActiveResellerSession() {
    if (!isset($_SESSION['mikhmon_role']) || $_SESSION['mikhmon_role'] !== 'reseller') {
        return true;
    }
    $uname = isset($_SESSION['mikhmon']) ? $_SESSION['mikhmon'] : '';
    $resellers = loadResellers();
    foreach ($resellers as $r) {
        if (isset($r['username']) && $r['username'] === $uname) {
            if (!isset($r['status']) || $r['status'] !== 'active') {
                session_destroy();
                return false;
            }
            $_SESSION['mikhmon_routers'] = isset($r['allowed_routers']) ? $r['allowed_routers'] : array();
            $_SESSION['mikhmon_permissions'] = isset($r['permissions']) ? $r['permissions'] : getDefaultPermissionMap(false);
            return true;
        }
    }
    session_destroy();
    return false;
}

/**
 * Check if current user is Administrator
 */
function isMikhmonAdmin() {
    if (!isset($_SESSION['mikhmon'])) {
        return false;
    }
    return !isset($_SESSION['mikhmon_role']) || $_SESSION['mikhmon_role'] === 'admin';
}

/**
 * Verify if current session user can access a router session
 */
function canAccessRouterSession($sessionName) {
    if (empty($sessionName)) {
        return false;
    }
    if (!syncActiveResellerSession()) {
        return false;
    }
    if (isMikhmonAdmin()) {
        return true;
    }
    $allowed = isset($_SESSION['mikhmon_routers']) && is_array($_SESSION['mikhmon_routers']) ? $_SESSION['mikhmon_routers'] : array();
    return in_array('*', $allowed, true) || in_array($sessionName, $allowed, true);
}

/**
 * Verify if current session user has a specific granular permission
 */
function hasResellerPermission($permKey) {
    if (!syncActiveResellerSession()) {
        return false;
    }
    if (isMikhmonAdmin()) {
        return true;
    }
    $perms = isset($_SESSION['mikhmon_permissions']) && is_array($_SESSION['mikhmon_permissions']) ? $_SESSION['mikhmon_permissions'] : array();
    return !empty($perms[$permKey]);
}

/**
 * Enforce permission server-side and redirect/halt if unauthorized
 */
function requireResellerPermission($permKey, $redirectUrl = './admin.php?id=sessions') {
    if (!hasResellerPermission($permKey)) {
        $defs = getAllMikhmonPermissionDefinitions();
        $label = isset($defs[$permKey]) ? $defs[$permKey]['label'] : $permKey;
        $thm = isset($_SESSION['theme']) && $_SESSION['theme'] !== '' ? $_SESSION['theme'] : 'dark';
        echo '<div class="row"><div class="col-6"><div class="card"><div class="card-header"><h3><i class="fa fa-ban text-danger"></i> Access Denied</h3></div><div class="card-body"><p>Your reseller account (<b>' . htmlspecialchars(isset($_SESSION['mikhmon']) ? $_SESSION['mikhmon'] : '', ENT_QUOTES) . '</b>) does not have permission for this operation: <b>' . htmlspecialchars($label, ENT_QUOTES) . '</b> (<code>' . htmlspecialchars($permKey, ENT_QUOTES) . '</code>).</p><a class="btn bg-primary" href="' . htmlspecialchars($redirectUrl, ENT_QUOTES) . '"><i class="fa fa-arrow-left"></i> Back</a></div></div></div></div></div></div><script src="./js/mikhmon-ui.' . htmlspecialchars($thm, ENT_QUOTES) . '.min.js"></script><script src="./js/mikhmon.js"></script></body></html>';
        exit;
    }
}
?>
