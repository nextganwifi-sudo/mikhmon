<?php
/*
 *  Copyright (C) 2018 Laksamadi Guko.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
session_start();
error_reporting(0);

if (!isset($_SESSION["mikhmon"])) {
    header("Location:../admin.php?id=login");
    exit;
}

include_once('./include/reseller_acl.php');

if (!isMikhmonAdmin()) {
    echo "<script>alert('Access Denied: Only Administrator can manage Reseller accounts.');window.location='./admin.php?id=sessions'</script>";
    exit;
}

$baseResellerUrl = !empty($session) ? "./?hotspot=resellers&session=" . urlencode($session) : "./admin.php?id=resellers";
$allRouters = getConfiguredRouterSessions();
$permCatalog = getAllMikhmonPermissionDefinitions();
$resellers = loadResellers();
$msg = "";

// Toggle active / disabled
if (isset($_GET['toggle-reseller']) && $_GET['toggle-reseller'] !== '') {
    $tid = $_GET['toggle-reseller'];
    foreach ($resellers as $idx => $r) {
        if ($r['id'] === $tid) {
            $resellers[$idx]['status'] = ($r['status'] === 'active') ? 'disabled' : 'active';
            break;
        }
    }
    saveResellers($resellers);
    echo "<script>window.location='" . $baseResellerUrl . "&edit-reseller=" . urlencode($tid) . "'</script>";
    exit;
}

// Delete reseller
if (isset($_GET['remove-reseller']) && $_GET['remove-reseller'] !== '') {
    $rid = $_GET['remove-reseller'];
    $filtered = array();
    foreach ($resellers as $r) {
        if ($r['id'] !== $rid) {
            $filtered[] = $r;
        }
    }
    saveResellers($filtered);
    echo "<script>window.location='" . $baseResellerUrl . "'</script>";
    exit;
}

// Save (Create or Update) reseller
if (isset($_POST['save_reseller'])) {
    $editId = isset($_POST['reseller_id']) ? trim($_POST['reseller_id']) : '';
    $rUser = preg_replace('/[^a-zA-Z0-9_\-\.]/', '', trim($_POST['r_username']));
    $rName = trim($_POST['r_name']);
    $rPass = isset($_POST['r_password']) ? (string)$_POST['r_password'] : '';
    $rStatus = (isset($_POST['r_status']) && $_POST['r_status'] === 'disabled') ? 'disabled' : 'active';
    $assignedRouters = isset($_POST['r_routers']) && is_array($_POST['r_routers']) ? array_values($_POST['r_routers']) : array();
    $postedPerms = isset($_POST['r_perms']) && is_array($_POST['r_perms']) ? $_POST['r_perms'] : array();

    $newPerms = getDefaultPermissionMap(false);
    foreach ($newPerms as $pk => $pv) {
        $newPerms[$pk] = !empty($postedPerms[$pk]);
    }

    if ($rUser === '' || strtolower($rUser) === strtolower($useradm)) {
        $msg = "<div class='bg-danger pd-5 radius-3'><i class='fa fa-ban'></i> Invalid Reseller Username (cannot be empty or equal to Admin username).</div>";
    } else {
        $duplicate = false;
        foreach ($resellers as $r) {
            if (strtolower($r['username']) === strtolower($rUser) && $r['id'] !== $editId) {
                $duplicate = true;
                break;
            }
        }
        if ($duplicate) {
            $msg = "<div class='bg-danger pd-5 radius-3'><i class='fa fa-ban'></i> Username <b>" . htmlspecialchars($rUser) . "</b> already exists.</div>";
        } else {
            if ($editId !== '') {
                foreach ($resellers as $idx => $r) {
                    if ($r['id'] === $editId) {
                        $resellers[$idx]['username'] = $rUser;
                        $resellers[$idx]['name'] = $rName !== '' ? $rName : $rUser;
                        $resellers[$idx]['status'] = $rStatus;
                        $resellers[$idx]['allowed_routers'] = $assignedRouters;
                        $resellers[$idx]['permissions'] = $newPerms;
                        if ($rPass !== '') {
                            $resellers[$idx]['password_hash'] = password_hash($rPass, PASSWORD_DEFAULT);
                            $resellers[$idx]['password_enc'] = encrypt($rPass);
                        }
                        break;
                    }
                }
                saveResellers($resellers);
                $msg = "<div class='bg-green pd-5 radius-3'><i class='fa fa-check'></i> Reseller <b>" . htmlspecialchars($rUser) . "</b> updated successfully.</div>";
            } else {
                if ($rPass === '') {
                    $rPass = '123456';
                }
                $newId = 'res_' . strtolower($rUser) . '_' . rand(100, 999);
                $resellers[] = array(
                    'id' => $newId,
                    'username' => $rUser,
                    'name' => $rName !== '' ? $rName : $rUser,
                    'password_hash' => password_hash($rPass, PASSWORD_DEFAULT),
                    'password_enc' => encrypt($rPass),
                    'status' => $rStatus,
                    'allowed_routers' => $assignedRouters,
                    'permissions' => $newPerms,
                    'created_at' => date('Y-m-d H:i:s'),
                );
                saveResellers($resellers);
                $editId = $newId;
                $msg = "<div class='bg-green pd-5 radius-3'><i class='fa fa-check'></i> Reseller <b>" . htmlspecialchars($rUser) . "</b> created successfully.</div>";
            }
        }
    }
}

$resellers = loadResellers();
$editingReseller = null;
$reqEditId = isset($_GET['edit-reseller']) ? $_GET['edit-reseller'] : (isset($editId) ? $editId : '');
if ($reqEditId === 'new') {
    $editingReseller = null;
} elseif ($reqEditId !== '') {
    foreach ($resellers as $r) {
        if ($r['id'] === $reqEditId) {
            $editingReseller = $r;
            break;
        }
    }
} elseif (!empty($resellers) && !isset($_GET['new'])) {
    $editingReseller = $resellers[0];
}

$formId = $editingReseller ? $editingReseller['id'] : '';
$formUser = $editingReseller ? $editingReseller['username'] : '';
$formName = $editingReseller ? $editingReseller['name'] : '';
$formStatus = $editingReseller ? $editingReseller['status'] : 'active';
$formRouters = $editingReseller && isset($editingReseller['allowed_routers']) ? $editingReseller['allowed_routers'] : array();
$formPerms = $editingReseller && isset($editingReseller['permissions']) ? $editingReseller['permissions'] : getStandardSellerPermissions();
?>
<script>
function PassReseller() {
    var x = document.getElementById('r_password');
    if (x.type === 'password') {
        x.type = 'text';
    } else {
        x.type = 'password';
    }
}
function setPermPreset(mode) {
    var boxes = document.querySelectorAll('.perm-checkbox');
    var std = ['view_dashboard','view_users','add_user','generate_voucher','edit_user','print_voucher','view_profiles','view_active','view_logs','view_report'];
    var ro = ['view_dashboard','view_users','view_profiles','view_active','view_hosts','view_ipbinding','view_cookies','view_dhcp','view_traffic','view_logs','view_report','view_scheduler','view_ppp'];
    for (var i = 0; i < boxes.length; i++) {
        var k = boxes[i].getAttribute('data-perm');
        if (mode === 'all') {
            boxes[i].checked = true;
        } else if (mode === 'none') {
            boxes[i].checked = false;
        } else if (mode === 'seller') {
            boxes[i].checked = (std.indexOf(k) !== -1);
        } else if (mode === 'readonly') {
            boxes[i].checked = (ro.indexOf(k) !== -1);
        }
    }
}
</script>

<div class="row">
  <div class="col-12">
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">
          <i class="fa fa-users"></i> Reseller Management
          &nbsp; | &nbsp;
          <a href="<?= $baseResellerUrl ?>&edit-reseller=new"><i class="fa fa-user-plus"></i> Add Reseller</a>
          &nbsp; | &nbsp;
          <a href="./admin.php?id=sessions"><i class="fa fa-server"></i> <?= $_router_list ?></a>
        </h3>
      </div>
      <div class="card-body">
        <?php if ($msg !== '') { echo "<div class='mr-b-10'>" . $msg . "</div>"; } ?>
        <div class="row">
          <!-- Left Column: Reseller Accounts List -->
          <div class="col-5">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title"><i class="fa fa-list"></i> Reseller List (<?= count($resellers); ?>)</h3>
              </div>
              <div class="card-body">
                <div class="overflow box-bordered" style="max-height: 70vh;">
                  <table class="table table-sm table-bordered table-hover text-nowrap">
                    <thead>
                      <tr>
                        <th class="text-center">Action</th>
                        <th><?= $_user_name ?></th>
                        <th><?= $_name ?></th>
                        <th>Assigned Routers</th>
                        <th>Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php if (empty($resellers)) { ?>
                        <tr><td colspan="5" class="text-center">No reseller accounts configured.</td></tr>
                      <?php } else {
                        foreach ($resellers as $r) {
                          $isCurrent = ($formId === $r['id']);
                          $rRouters = isset($r['allowed_routers']) && !empty($r['allowed_routers']) ? implode(', ', $r['allowed_routers']) : 'None';
                          $statusBadge = ($r['status'] === 'active')
                            ? "<b class='text-green'>Active</b>"
                            : "<b class='text-red'>Disabled</b>";
                      ?>
                        <tr style="<?= $isCurrent ? 'font-weight:bold;' : '' ?>">
                          <td class="text-center">
                            <a href="<?= $baseResellerUrl ?>&edit-reseller=<?= urlencode($r['id']); ?>" title="Edit <?= htmlspecialchars($r['username']); ?>"><i class="fa fa-edit text-primary"></i></a>
                            &nbsp;
                            <a href="<?= $baseResellerUrl ?>&toggle-reseller=<?= urlencode($r['id']); ?>" title="<?= $r['status'] === 'active' ? 'Deactivate' : 'Activate'; ?> <?= htmlspecialchars($r['username']); ?>">
                              <i class="fa <?= $r['status'] === 'active' ? 'fa-unlock text-green' : 'fa-lock text-warning'; ?>"></i>
                            </a>
                            &nbsp;
                            <a href="javascript:void(0)" onclick="if(confirm('Delete reseller <?= htmlspecialchars($r['username'], ENT_QUOTES); ?>?')){window.location='<?= $baseResellerUrl ?>&remove-reseller=<?= urlencode($r['id']); ?>'}" title="Delete <?= htmlspecialchars($r['username']); ?>">
                              <i class="fa fa-minus-square text-danger"></i>
                            </a>
                          </td>
                          <td>
                            <a href="<?= $baseResellerUrl ?>&edit-reseller=<?= urlencode($r['id']); ?>">
                              <?= htmlspecialchars($r['username']); ?>
                            </a>
                          </td>
                          <td><?= htmlspecialchars($r['name']); ?></td>
                          <td><?= htmlspecialchars($rRouters); ?></td>
                          <td><?= $statusBadge; ?></td>
                        </tr>
                      <?php } } ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

          <!-- Right Column: Create / Edit Reseller, Router Assignments & Granular Permissions -->
          <div class="col-7">
            <form autocomplete="off" method="post" action="<?= $baseResellerUrl ?><?= $formId ? '&edit-reseller=' . urlencode($formId) : '&edit-reseller=new' ?>">
              <input type="hidden" name="reseller_id" value="<?= htmlspecialchars($formId); ?>">
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fa <?= $formId ? 'fa-edit' : 'fa-user-plus'; ?>"></i>
                    <?= $formId ? 'Edit Reseller: ' . htmlspecialchars($formUser) : 'Add New Reseller'; ?>
                  </h3>
                </div>
                <div class="card-body">
                  <div class="mr-b-10">
                    <button type="submit" name="save_reseller" class="btn bg-primary"><i class="fa fa-save"></i> <?= $_save ?></button>
                    <a class="btn bg-warning" href="<?= $baseResellerUrl ?>&edit-reseller=new"><i class="fa fa-plus"></i> New Reseller</a>
                  </div>

                  <table class="table table-sm">
                    <tr>
                      <td class="align-middle" style="width: 30%;"><?= $_user_name ?></td>
                      <td>
                        <input class="form-control" type="text" name="r_username" value="<?= htmlspecialchars($formUser); ?>" placeholder="e.g. kiosk_utara" required="1">
                      </td>
                    </tr>
                    <tr>
                      <td class="align-middle"><?= $_name ?></td>
                      <td>
                        <input class="form-control" type="text" name="r_name" value="<?= htmlspecialchars($formName); ?>" placeholder="Outlet / Reseller Full Name" required="1">
                      </td>
                    </tr>
                    <tr>
                      <td class="align-middle"><?= $_password ?> <?= $formId ? '<small>(Leave blank to keep)</small>' : '' ?></td>
                      <td>
                        <div class="input-group">
                          <div class="input-group-11 col-box-10">
                            <input class="group-item group-item-l" id="r_password" type="password" name="r_password" value="" placeholder="<?= $formId ? 'Enter new password to reset' : 'Password'; ?>" <?= $formId ? '' : 'required="1"' ?>>
                          </div>
                          <div class="input-group-1 col-box-2">
                            <div class="group-item group-item-r pd-2p5 text-center align-middle">
                              <input title="Show/Hide Password" type="checkbox" onclick="PassReseller()">
                            </div>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td class="align-middle">Account Status</td>
                      <td>
                        <select class="form-control" name="r_status">
                          <option value="active" <?= $formStatus === 'active' ? 'selected' : ''; ?>>Active (Can Login)</option>
                          <option value="disabled" <?= $formStatus === 'disabled' ? 'selected' : ''; ?>>Disabled (Suspended)</option>
                        </select>
                      </td>
                    </tr>
                    <tr>
                      <td class="align-middle">Assigned Routers<br><small>Server-side isolated</small></td>
                      <td>
                        <?php if (empty($allRouters)) { ?>
                          <span>No routers configured in Mikhmon yet.</span>
                        <?php } else {
                          foreach ($allRouters as $rSess) {
                            $checked = in_array($rSess, $formRouters, true) ? 'checked' : '';
                            $rHotspotName = isset($data[$rSess][4]) ? explode('%', $data[$rSess][4])[1] : $rSess;
                        ?>
                          <label style="display:inline-block; margin-right: 14px; cursor:pointer;">
                            <input type="checkbox" name="r_routers[]" value="<?= htmlspecialchars($rSess); ?>" <?= $checked; ?>>
                            <b><?= htmlspecialchars($rSess); ?></b> (<?= htmlspecialchars($rHotspotName); ?>)
                          </label>
                        <?php } } ?>
                      </td>
                    </tr>
                  </table>

                  <div class="card mr-t-10">
                    <div class="card-header">
                      <h3 class="card-title">
                        <i class="fa fa-lock"></i> Granular Operation Permissions
                        <span style="font-size: 12px; font-weight: normal;">
                          &nbsp; | &nbsp; Quick Select:
                          <a href="javascript:void(0)" onclick="setPermPreset('seller')">Standard Reseller</a> &middot;
                          <a href="javascript:void(0)" onclick="setPermPreset('readonly')">Read-Only</a> &middot;
                          <a href="javascript:void(0)" onclick="setPermPreset('all')">Enable All</a> &middot;
                          <a href="javascript:void(0)" onclick="setPermPreset('none')">Disable All</a>
                        </span>
                      </h3>
                    </div>
                    <div class="card-body">
                      <?php foreach ($permCatalog as $groupName => $groupPerms) { ?>
                        <div style="margin-bottom: 10px;">
                          <div style="font-weight: bold; padding: 4px 0; border-bottom: 1px solid rgba(255,255,255,0.1); margin-bottom: 6px;">
                            <i class="fa fa-check-square-o"></i> <?= htmlspecialchars($groupName); ?>
                          </div>
                          <div class="row">
                            <?php foreach ($groupPerms as $pKey => $pLabel) {
                              $isChecked = !empty($formPerms[$pKey]) ? 'checked' : '';
                            ?>
                              <div class="col-6" style="padding: 2px 8px;">
                                <label style="cursor:pointer; font-weight:normal;">
                                  <input type="checkbox" class="perm-checkbox" data-perm="<?= htmlspecialchars($pKey); ?>" name="r_perms[<?= htmlspecialchars($pKey); ?>]" value="1" <?= $isChecked; ?>>
                                  <?= htmlspecialchars($pLabel); ?>
                                </label>
                              </div>
                            <?php } ?>
                          </div>
                        </div>
                      <?php } ?>
                    </div>
                  </div>

                  <div class="mr-t-10">
                    <button type="submit" name="save_reseller" class="btn bg-primary"><i class="fa fa-save"></i> <?= $_save ?></button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
